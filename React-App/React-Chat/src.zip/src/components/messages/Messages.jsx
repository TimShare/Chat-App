import React, { useEffect, useState } from "react";
import axios from "axios";
import FormatDate from "../../helpers/FormatDate";
import "./Messages.css"; // Импортируйте ваш CSS файл

const Messages = ({ chat, ws }) => {
  const [messages, setMessages] = useState([]);
  useEffect(() => {
    const fetchMessages = async () => {
      try {
        const response = await axios.get(`http://localhost:8000/messages`, {
          params: { chat_id: chat.id }, // Отправка параметра chat_id
        });

        // Убедитесь, что вы правильно обрабатываете данные
        const loadedMessages = response.data; // Получение данных из ответа
        setMessages(loadedMessages); // Установка загруженных сообщений в состояние
      } catch (error) {
        console.error("Ошибка при загрузке сообщений:", error);
      }
    };

    fetchMessages(); // Вызов функции для загрузки сообщений
  }, [chat.id]);

  useEffect(() => {
    if (ws) {
      const handleMessage = (event) => {
        const newMessage = JSON.parse(event.data);

        setMessages((prevMessages) => [...prevMessages, newMessage]);
      };

      ws.onmessage = handleMessage;

      return () => {
        ws.onmessage = null;
      };
    }
  }, [ws]);
  return (
    <div className="messages">
      <ul className="messages-list">
        {messages.length > 0 ? (
          messages.map((message, index) => (
            <li key={index} className="message-item">
              <span className="message-author">{message.username}</span>
              <span className="message-content">{message.content}</span>
              <span className="message-time">
                {FormatDate(message.created_at)}
              </span>
            </li>
          ))
        ) : (
          <p>Нет сообщений в этом чате.</p>
        )}
      </ul>
    </div>
  );
};

export default Messages;
