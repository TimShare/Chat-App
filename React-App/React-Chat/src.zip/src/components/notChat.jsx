const NotChat = () => {
  return (
    <main className="chat-window">
      <div className="chat-header">
        <span className="chat-username">
          Выберите чат для просмотра сообщений
        </span>
      </div>
    </main>
  );
};

export default NotChat;
