import { useEffect, useState } from "react";
import Sidebar from "../sidebar/Sidebar";
import ChatWindow from "../chatWindow/ChatWindow";
import "./ChatApp.css";

const ChatApp = ({ userdata, setUserdata }) => {
  const [ws, setWs] = useState(null); // Create a state for WebSocket
  const [isConnected, setIsConnected] = useState(false);
  const [selectedChat, setSelectedChat] = useState(null); // State for selected chat

  useEffect(() => {
    if (userdata) {
      const connectWebSocket = () => {
        const websocket = new WebSocket(
          `ws://localhost:8000/ws/${userdata.id}`
        );
        setWs(websocket); // Store the WebSocket in the state

        websocket.onopen = () => {
          console.log("WebSocket соединение установлено");
          setIsConnected(true); // Update connection status
        };

        websocket.onclose = () => {
          console.log("WebSocket соединение закрыто");
          setIsConnected(false); // Update connection status
          // Автоматическое повторное подключение через 3 секунды
          setTimeout(connectWebSocket, 3000);
        };

        websocket.onerror = (error) => {
          console.error("WebSocket ошибка:", error);
          websocket.close(); // Закрываем WebSocket при ошибке
        };
      };

      connectWebSocket(); // Initial connection attempt

      return () => {
        if (ws && ws.readyState === WebSocket.OPEN) {
          ws.close(); // Clean up when component unmounts
          console.log("Соединение WebSocket закрыто");
        }
      };
    }
  }, [userdata]);

  return (
    <div className="chat-container">
      <Sidebar
        userdata={userdata}
        setUserdata={setUserdata}
        ws={ws}
        setSelectedChat={setSelectedChat} // Pass setSelectedChat to Sidebar
      />
      <ChatWindow chat={selectedChat} userdata={userdata} ws={ws} />
      {/* Pass selected chat to ChatWindow */}
    </div>
  );
};

export default ChatApp;
