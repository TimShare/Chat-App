import React, { useState, useEffect } from "react";
import axios from "axios";
import Chat_list from "../chat_list/Chat_List";
import "./Sidebar.css";
import Modal from "../modal/Modal";

const Sidebar = ({ userdata, setUserdata, ws, setSelectedChat }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [userChats, setUserChats] = useState([]);
  const user_id = userdata.id;

  // Функция для получения чатов пользователя
  const fetchUserChats = async () => {
    try {
      const response = await axios.get(
        `http://localhost:8000/users/${user_id}/chats`
      );
      setUserChats(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    if (user_id) {
      fetchUserChats(); // Получаем чаты при монтировании

      if (ws) {
        ws.onmessage = (event) => {
          console.log("Новое сообщение от WebSocket:", event.data);
          fetchUserChats();
        };
      }

      return () => {
        // Опционально добавьте очистку, если это необходимо
      };
    }
  }, [user_id, ws]); // Следите за изменениями user_id и ws

  // Функция для обработки выбора чата
  const handleChatSelect = (chatId) => {
    const selectedChat = userChats.find((chat) => chat.id === chatId); // Найдите чат по ID
    setSelectedChat(selectedChat); // Установите выбранный чат
    // console.log(selectedChat);
  };

  return (
    <aside className="sidebar">
      <div className="profile">
        <span>{userdata.username}</span>
        <button className="new-chat" onClick={() => setIsModalOpen(true)}>
          Новый чат
        </button>
      </div>

      {userChats && (
        <Chat_list userChats={userChats} onChatSelect={handleChatSelect} />
      )}
      {isModalOpen && (
        <Modal
          userdata={userdata}
          setIsModalOpen={setIsModalOpen}
          onChatCreated={fetchUserChats} // Обновите список чатов, когда создается новый чат
        />
      )}
    </aside>
  );
};

export default Sidebar;
