from fastapi import Depends, FastAPI, HTTPException, WebSocket, WebSocketDisconnect
import json
from sqlalchemy.orm import Session
from typing import List
from . import crud, models, schemas
from .database import SessionLocal, engine
from fastapi.middleware.cors import CORSMiddleware
from datetime import datetime
models.Base.metadata.create_all(bind=engine)

app = FastAPI()

# Глобальная переменная для хранения активных соединений
active_connections = {}

origins = [
    "*",  # Например, для React, если он запущен на порту 3000
    "https://your-frontend-domain.com"  # Другие домены, с которых разрешены запросы
]

# Добавление CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,  # Разрешенные домены
    allow_credentials=True,  # Если нужно поддерживать передачу cookie
    allow_methods=["*"],  # Разрешенные методы (GET, POST и т.д.)
    allow_headers=["*"],  # Разрешенные заголовки
)


# Dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@app.post("/register/", response_model=schemas.User)
def register_user(user: schemas.UserCreate, db: Session = Depends(get_db)):
    db_user = crud.get_user_by_email(db, email=user.email, )
    if db_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    return crud.create_user(db=db, user=user)


@app.post("/login/", response_model=schemas.User)
def login(login_data: schemas.Login, db: Session = Depends(get_db)):
    # Проверяем пользователя по логину (email или username) и паролю
    user = crud.authenticate_user(db, login=login_data.login, password=login_data.password)

    return user


@app.get("/users/{user_id}/chats", response_model=List[schemas.Chat])
def read_user_chats(user_id: int, db: Session = Depends(get_db)):
    chats = crud.get_user_chats(db, user_id)
    return chats


@app.get("/chats/", response_model=List[schemas.Chat])
def get_chats(skip: int = 0, limit: int = 10, db: Session = Depends(get_db)):
    return crud.get_chats(db, skip=skip, limit=limit)


@app.post("/chats/", response_model=schemas.Chat)
async def create_chat(chat: schemas.ChatCreate, db: Session = Depends(get_db)):
    for connection in active_connections.values():
        await connection.send_text(f"New member chat")
        print("new chat")
    return crud.create_chat(db=db, chat=chat)


@app.post("/chats/{chat_id}/add_user/")
async def add_user_to_chat_endpoint(chat_id: int, user_id: int, db: Session = Depends(get_db)):
    for connection in active_connections.values():
        await connection.send_text("XDD")

    return crud.add_user_to_chat(db, chat_id=chat_id, user_id=user_id)


@app.post("/messages/", response_model=schemas.Message)
async def create_message(message: schemas.MessageCreate, chat_id: int, current_user: int, db: Session = Depends(get_db)
                         ):
    chat = crud.create_message(db=db, message=message, chat_id=chat_id, sender_id=current_user)

    return chat


@app.get("/messages", response_model=List[schemas.Message])
def get_messages_in_chat(chat_id: int, db: Session = Depends(get_db)):
    messages = crud.get_messages_in_chat(db=db, chat_id=chat_id)
    return messages


@app.post("/private-chat/")
async def create_private_chat(to_user_id: int, current_user: int, db: Session = Depends(get_db)):

    return crud.create_private_chat(db=db, to_user_id=to_user_id, current_user=current_user)


@app.websocket("/ws/{user_id}")
async def websocket_endpoint(websocket: WebSocket, user_id: int, db: Session = Depends(get_db)):
    await websocket.accept()
    crud.set_user_online(db, user_id)
    # Сохраняем соединение
    active_connections[user_id] = websocket
    try:
        while True:
            message = await websocket.receive_text()
            data = json.loads(message)
            # Доступ к данным из сообщения

            chat_id = data.get("chat_id")
            content = data.get("content")
            sender_id = data.get("sender_id")
            if chat_id and content and sender_id:
                await create_message(message=schemas.MessageCreate(content=content), chat_id=chat_id, current_user=sender_id, db=db)
                for connection in active_connections.values():
                    data["username"] = crud.from_id_to_username(db=db, user_id=data["sender_id"])
                    data["created_at"] = datetime.now().isoformat()
                    await connection.send_text(json.dumps(data))
            else:
                await websocket.send_text("Некорректные данные")
    except WebSocketDisconnect:
        print(f"Пользователь {user_id} отключился")
        crud.set_user_offline(db, user_id)
        del active_connections[user_id]
    except Exception as e:
        print(f"Ошибка WebSocket для пользователя {user_id}: {e}")
